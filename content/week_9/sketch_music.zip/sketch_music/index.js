// Computational Music Examples
// ---
//
// MonoSynth Examples
// - [sketch_basic.html](sketch_basic.html)
// - [sketch_random.html](sketch_random.html)
// - [sketch_brownian.html](sketch_brownian.html)
// - [sketch_record_output.html](sketch_record_output.html)
//
// QuickMusic + MonoSynth Examples
// - [sketch_quickmusic.html](sketch_quickmusic.html)
// - [sketch_organized.html](sketch_organized.html)
// - [sketch_kitchen.html](sketch_kitchen.html)
